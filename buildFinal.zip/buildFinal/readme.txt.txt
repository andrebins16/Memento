André Bins, Lucas Bandeira, Marcos Ferreira, Vermon Aguiar e Natália Dal Pizzol

O zip do projeto inteiro é muito grande para enviar pelo moodle, logo foi enviado só o build.

Repositório do projeto: https://github.com/andrebins16/Memento

